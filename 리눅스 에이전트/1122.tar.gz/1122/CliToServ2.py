import os
import sys
index=0
os.system('top -n 1 > top_token_test.txt')
textfile = open("top_token_test.txt",'r')
read_textfile = textfile.read()

slist=read_textfile.split("\n")

dic_key_list = slist[6].split()
json_dict = {dic_key_list[1]:'',dic_key_list[2]:'',dic_key_list[9]:'',dic_key_list[10]:'',dic_key_list[12]:''}

for i in range(7,len(slist)-1):
    dic_value_list=slist[i].split()
    json_dict[index]= {dic_key_list[1]:dic_value_list[1],dic_key_list[2]:dic_value_list[2],dic_key_list[9]:dic_value_list[9],dic_key_list[10]:dic_value_list[10],dic_key_list[12]:dic_value_list[12]}
    index+=1
print(type(json_dict))
print(json_dict)

import  json
stringOfJsonData = json.dumps(json_dict)

print('json  \n\n\n\n')
print(stringOfJsonData)

savefile = open('top_parsing.json','w')
savefile.write(stringOfJsonData)

#os.system('curl -X DELETE http://14.63.166.83/api/info/process/(usernum)/delete/?format='json')
#os.system('curl -X POST http://14.63.166.83/api/info/process/?format=json')
 
