#include <sys/types.h> 
#include <sys/stat.h> 
#include <stdio.h> 
#include <fcntl.h> 

int main()
{
    pid_t   pid;
	
	system("python required_Iface.py");
	sleep(3);
	
	system("./network1");
	system("python urlopen.py");
	

	system("python ip_user_matching.py");
	

	//system("./alrmtop");

    if (( pid = fork()) < 0)
    exit(0);

    // 부모프로세스를 종료한다. 
    else if(pid == 0){   
    
    //chdir("/");

    // 여기에 프로그램 본체를 넣는다. 
    	setsid();    
    	while(1)
		{
			printf("데몬작동중");
			system("python Make_dic.py");
			sleep(5);
			system("python disk_dic.py");
    		sleep(60);
		}
	}
	else exit(0);
}
