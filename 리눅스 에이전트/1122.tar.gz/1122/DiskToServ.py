# 디스크 크기 파싱 및 json 전환
import json
import os
import sys


os.system("df -P | grep -v ^Filesystem | awk '{sum += $2} END { print sum/1024/1024}'>full_v.txt")
# 전체 용량
os.system("df -P | grep -v ^Filesystem | awk '{sum += $3} END { print sum/1024/1024}'>used_v.txt")
# 전체 사용량
os.system("df -P | grep -v ^Filesystem | awk '{sum += $4} END { print sum/1024/1024}'>rest_v.txt")
# 전체 잔여 용량

volume_full = open('full_v.txt','r')
volume_used = open('used_v.txt','r')
volume_rest = open('rest_v.txt','r')
#유저 아이디 추가 해야함 !


dic_vol ={'full':volume_full.read().strip(), 'used':volume_used.read().strip(), 'rest':volume_rest.read().strip() }

#print(dic_vol)

stringOfJsonVolume = json.dumps(dic_vol)
#print(stringOfJsonVolume)

savefile = open('disk_passing.json','w')
savefile.write(stringOfJsonVolume)
