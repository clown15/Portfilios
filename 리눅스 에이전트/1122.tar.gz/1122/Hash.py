import subprocess
import re

proc=subprocess.Popen('sha1sum Daemon Kill_Parsing alrmtop network1 network2 userget CliToServ2.py DiskToServ.py Kill.py Make_dic.py chmodANDRun.py disk_dic.py ip_user_matching.py required_Iface.py urlopen.py'.split(),stdout=subprocess.PIPE)

temp=proc.communicate()

cli_hash=str(temp[0]).split('\n')
#print(cli_hash)
for i in range(len(cli_hash)):
	#if(i==0): cli_hash[i]=cli_hash[i][2:]
	cli_hash[i]=cli_hash[i].split(' ')
	#print(cli_hash[i][0])

proc=subprocess.Popen('curl -X GET http://14.63.166.83/api/login/version/?format=json'.split(),stdout=subprocess.PIPE)

serv_hash=proc.communicate()
reg=re.compile(r'\w{5,}')
serv_hash=reg.findall(str(serv_hash[0]))
print(serv_hash)
for i in range(len(cli_hash)-1):
	if cli_hash[i][0] not in serv_hash:
		#print(cli_hash[i][0])
		#print("file error")
		break
	else: print(i,"OK")
