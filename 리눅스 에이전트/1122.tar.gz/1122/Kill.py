import os
import sys
import re

txtfile = open('ip_user_matching.txt','r')
usertxt = txtfile.read()
usertxt = usertxt.strip()
os.system('curl -o test2.json http://14.63.166.83/api/info/kill/?format=json')

killfile = open('test2.json','r')
killtxt = killfile.read()
killtxt = killtxt.strip()


alist = killtxt.split("},{")
matchrull_kill_user = re.compile(r'r":(.*),')
matchrull_kill_pid = re.compile(r'd":([0-9]*)')

user_array =[]
pid_array =[]

for i in range(0,len(alist)):
	match_first = matchrull_kill_user.search(alist[i])
	if match_first is not None:
		user_array.append(matchrull_kill_user.search(alist[i]).group(1))
		pid_array.append(matchrull_kill_pid.search(alist[i]).group(1))

for i in range(0,len(alist)):
	if user_array[i] == str(usertxt):
		os.system("kill -9 "+pid_array[i])

txtfile.close()
killfile.close()


