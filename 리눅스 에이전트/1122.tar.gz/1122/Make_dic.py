import os

import sys

import json

 

os.system('top -n 1 > top_token_test.txt')

 

textfile = open('top_token_test.txt', 'r')

os.system('rm -f top_passing.json')

 

savefile = open('top_passing.json', 'a')

user_idfile = open('ip_user_matching.txt','r')

 

read_textfile = textfile.read()

user_id = user_idfile.read()
user_id = user_id.strip()

 

alist = read_textfile.split("\n")

dic_key_list = alist[6].split()

 

 

json_dict={}

 

for i in range(7, len(alist)-1):

        dic_value_list=alist[i].split()

        json_dict = {'user': user_id , 'pid' : int(dic_value_list[1]), 'pname' : dic_value_list[12], 'memory' : float(dic_value_list[10]), 'cpu' : float(dic_value_list[9])}

        stringOfJsonData = json.dumps(json_dict)

        if i==7:

                savefile.write('[')

        savefile.write(stringOfJsonData)

        if i==len(alist)-2:

                savefile.write(']')

        else:

                savefile.write(',')

 

os.unlink('top_token_test.txt')

savefile.close()
os.system("python Kill.py")
os.system("curl -X DELETE http://14.63.166.83/api/info/kill/"+user_id+"/delete/?format=json")
os.system("curl -X DELETE http://14.63.166.83/api/info/process/"+user_id+"/delete/?format=json")

os.system('curl -X POST http://14.63.166.83/api/info/process/create/?format=json -d @top_passing.json -H "Content-Type: application/json"')
