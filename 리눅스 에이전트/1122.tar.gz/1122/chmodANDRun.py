import os
import sys

os.system('chmod 4755 ./network1')
os.system('chmod 4755 ./network2')



