import json
import os
import sys
 
 
os.system("df -P | grep -v ^Filesystem | awk '{sum += $2} END { print sum/1024/1024}'>full_v.txt")
# full
os.system("df -P | grep -v ^Filesystem | awk '{sum += $3} END { print sum/1024/1024}'>used_v.txt")
# used
os.system("df -P | grep -v ^Filesystem | awk '{sum += $4} END { print sum/1024/1024}'>rest_v.txt")
# rest
 
volume_full = open('full_v.txt','r')
volume_used = open('used_v.txt','r')
volume_rest = open('rest_v.txt','r')
 
user_idfile = open('ip_user_matching.txt','r')
user_id=user_idfile.read()
user_id=user_id.strip()
 
 
dic_vol ={'user': user_id ,'full':float(volume_full.read().strip()), 'used':float(volume_used.read().strip()), 'rest':float(volume_rest.read().strip()) }
 
 
 
stringOfJsonVolume = json.dumps(dic_vol)
#print(stringOfJsonVolume)
 
savefile = open('disk_passing.json','w')
savefile.write(stringOfJsonVolume)
'''
os.system("DISK_TOTAL=`df -P | grep -v ^Filesystem | awk '{sum += $2} END { print sum; }'`")
os.system("DISK_USED=`df -P | grep -v ^Filesystem | awk '{sum += $3} END { print sum; }'`")
'''
 
os.unlink('full_v.txt')
os.unlink('used_v.txt')
os.unlink('rest_v.txt')
savefile.close()
user_idfile.close()
os.system("curl -X DELETE http://14.63.166.83/api/info/disk/"+user_id+"/delete/?format=json")
os.system('curl -X POST http://14.63.166.83/api/info/disk/create/?format=json -d @disk_passing.json -H "Content-Type: application/json"')
