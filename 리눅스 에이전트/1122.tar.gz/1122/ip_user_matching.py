# ip_list open, ip user matching
import json
import os
import sys
import re
k=True
while k:
	os.system("./userget")
	iplistfile = open('ip_matching.json','r')
	 
	read_textfile = iplistfile.read()
	 
	alist = read_textfile.split("},{")

	print(alist[0])
	 
	matchrull_user = re.compile(r'r":(.*),')
	matchrull_ip = re.compile(r'p":"(.*)"')
	 
	user_array = []
	ip_array = []
	 
	user_searchcount = 1
	 
	for i in range(0, len(alist)):
		match1 = matchrull_user.search(alist[i])
		if match1 is not None:
			user_array.append(matchrull_user.search(alist[i]).group(1))
			ip_array.append(matchrull_ip.search(alist[i]).group(1))
	'''
	print(user_array)
	print(ip_array)
	print(type(alist))
	'''
 

 	#server_ip useing case
 
	myipfile=open('myip.txt','r')
	myip = myipfile.read()
	myip=myip.strip()
	 
	matchingfile = open('ip_user_matching.txt','w')
	 
	for i in range(0, len(ip_array)):
		if ip_array[i]==str(myip) and user_searchcount!=0:
		        matchingfile.write(user_array[i])
		        os.system('curl -DELETE http:14.63.166.83/api/login/loginuser/'+user_array[i]+'/delete/?format=json')
		        user_searchcount-=1
		        os.system('./network2')
		        k=False
		elif i == len(ip_array)-1:
		        print("don't search")
	 
	matchingfile.close()
	myipfile.close()
	iplistfile.close()
