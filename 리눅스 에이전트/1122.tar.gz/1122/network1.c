#include <stdio.h>
#include <stdlib.h>

int main(){
	int a;
	
	FILE *fp;
	char addr[100];
	char addr2[100];
	char buf[1000];
	char buf1[1000];
	char buf2[1000];
	system("curl ifconfig.me > myip.txt");

	fp=fopen("gateway_info.txt", "r");

	fscanf(fp,"%s %s",addr,addr2);
	printf("%s\n%s\n",addr,addr2);

	sprintf(buf, "route add -net 14.63.166.83 netmask 255.255.255.255 gw %s",addr);
	sprintf(buf1, "route del default gw %s", addr);
	sprintf(buf2, "route add default gw %s9", addr2);
	setreuid(0,0);
	//system("route add -net 14.63.166.83 netmask 255.255.255.255 gw 192.168.248.2");
	system(buf2);	
	system(buf);
	
	system(buf1);

	return 0;
}

