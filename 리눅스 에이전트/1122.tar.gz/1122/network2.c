#include <stdio.h>
#include <stdlib.h>

int main(){
	int a;
	FILE *fp;
	char addr[100];
	char addr2[100];
	char buf[1000];
	char buf2[1000];

	fp=fopen("gateway_info.txt", "r");

	fscanf(fp,"%s %s",addr,addr2);
	//printf("%s\n%s\n",addr,addr2);
	sprintf(buf,"route add default gw %s",addr);
	sprintf(buf2,"route del default gw %s9",addr2);		

	setreuid(0,0);
	//system("ifconfig ens33 192.168.248.2 netmask 255.255.255.0 up");
	//system("route add -net default netmask 0.0.0.0 gw 192.168.248.2 dev ens33");
	system(buf);
	system(buf2);

	return 0;
}

