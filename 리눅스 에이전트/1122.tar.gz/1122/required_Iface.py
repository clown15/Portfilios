import sys

import os

 

os.system('netstat -rn > temp_routeinfo.txt')

 

routefile = open('temp_routeinfo.txt','r')

 

content = routefile.read()

 

alist = content.split("\n")

 

iface_info = alist[2].split()

 

gateway_string=iface_info[1]
gateway_split = gateway_string.split('.')
gateway_string_plus = gateway_split[0]+'.'+ gateway_split[1]+'.'+ gateway_split[2]+'.'

 

os.unlink('temp_routeinfo.txt')

 

routefile.close()

 

print(gateway_string)

print(gateway_string_plus)

 

savefile = open('gateway_info.txt','w')

 

savefile.write(gateway_string+' ')

savefile.write(gateway_string_plus)

savefile.close()
