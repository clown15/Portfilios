import webbrowser
url="http://14.63.166.83/"
webbrowser.open(url)

