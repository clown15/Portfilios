#include <stdio.h>
#include <string.h>
 
#define MAXLINE 2000
int main()
{
        FILE *fp_api;
        int state_ip, state_api;
        char buff_ip_matching[MAXLINE];
 
        fp_api = popen("curl -o ip_matching.json http://14.63.166.83/api/login/loginuser/?format=json","r");
 
        while(fgets(buff_ip_matching, MAXLINE, fp_api) !=NULL)
        {
                printf("%s",buff_ip_matching);
        }
 
        return 0;
}
