from django.apps import AppConfig


class Info1Config(AppConfig):
    name = 'info'
