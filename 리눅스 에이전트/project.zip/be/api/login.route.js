const express = require('express')
const loginRoutes = express.Router();

let User = require('./login.model');

loginRoutes.route('/add').post(function (req, res) {
    let user = new User(req.body);
    user.save()
        .then(() => {
            res.status(200).json({'business': 'business in added successfully'});
        })
        .catch(() => {
            res.status(400).send("unable to save to db");
        });
});

loginRoutes.route('/').get(function (req, res) {
    User.find(function (err, users) {
        if(err) {
            res.json(err);
        }
        else {
            res.json(users);
        }
    });
});

loginRoutes.route('/').post(function (req, res) {
    User.find(function (err, users) {
        let isUser = false
        if(err) {
            res.json(err);
        }
        else {
            users.forEach( function ( v, i ) {
                if (v.email === req.body.email){
                    isUser = true
                    if (v.password === req.body.password)
                        res.json({ result: 1 , resUser: v })
                    else
                        res.json({ result: -1 })
                }
            })
            if (!isUser)
                res.json({ result: 0 })
        }
    });
});

loginRoutes.route('/:reqid').get(function (req, res) {
    let id = req.params.reqid;
    User.findById(id, function (err, user){
        if(err) {
            res.json(err);
        }
        if(user.isAdmin === true)
            res.json({ result: true });
        else
            res.json({ result: false });
    });
});

loginRoutes.route('/edit/:id').get(function (req, res) {
    let id = req.params.id;
    User.findById(id, function (err, user){
        if(err) {
            res.json(err);
        }
        res.json(user);
    });
});

loginRoutes.route('/update/:id').post(function (req, res) {
    User.findById(req.params.id, function (err, user) {
        if(!user)
            req.status(404).send("data is not found");
        else {
            user.email = req.body.email;
            user.password = req.body.password;
            user.name = req.body.name;
            user.number = req.body.number;
            user.phoneNum = req.body.phoneNum;
            user.isAdmin = req.body.isAdmin;
            user.save().then(() => {
                res.json('Update complete');
            })
                .catch(() => {
                    res.status(400).send("unable to update the db");
                });
        }
    });
});

loginRoutes.route('/delete/:id').delete(function (req, res) {
    User.findByIdAndRemove({_id: req.params.id}, function(err){
        if(err)
            res.json(err);
        else
            res.json('Successfully removed');
    });
});

module.exports = loginRoutes;
