const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let WaitUser = new Schema({
    email: {
        type: String
    },
    password: {
        type: String
    },
    name: {
        type: String
    },
    number: {
        type: String
    },
    phoneNum: {
        type: String
    },
    isAdmin: {
        type: Boolean
    }
},{
    collection: 'waitUsers'
});

module.exports = mongoose.model('WaitUser', WaitUser);
