const express = require('express')
const waitUserRoutes = express.Router();

let WaitUser = require('./waitUser.model');

waitUserRoutes.route('/add').post(function (req, res) {
    let waitUser = new WaitUser(req.body);
    waitUser.save()
        .then(() => {
            res.status(200).json({'business': 'business in added successfully'});
        })
        .catch(() => {
            res.status(400).send("unable to save to db");
        });
});

waitUserRoutes.route('/').get(function (req, res) {
    WaitUser.find(function (err, waitUsers) {
        if(err) {
            res.json(err);
        }
        else {
            res.json(waitUsers);
        }
    });
});

waitUserRoutes.route('/edit/:id').get(function (req, res) {
    let id = req.params.id;
    WaitUser.findById(id, function (err, waitUser){
        if(err) {
            res.json(err);
        }
        res.json(waitUser);
    });
});

waitUserRoutes.route('/update/:id').post(function (req, res) {
    WaitUser.findById(req.params.id, function (err, waitUser) {
        if(!waitUser)
            req.status(404).send("data is not found");
        else {
            waitUser.title = req.body.title;
            waitUser.body = req.body.body;
            waitUser.save().then(() => {
                res.json('Update complete');
            })
                .catch(() => {
                    res.status(400).send("unable to update the db");
                });
        }
    });
});

waitUserRoutes.route('/delete/:id').delete(function (req, res) {
    WaitUser.findByIdAndRemove({_id: req.params.id}, function(err){
        if(err)
            res.json(err);
        else
            res.json('Successfully removed');
    });
});

module.exports = waitUserRoutes;
