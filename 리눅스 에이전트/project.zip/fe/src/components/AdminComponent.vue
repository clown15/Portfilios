<template>
  <div>
    <h1>Admin Page</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'posts', params: { reqid: id }}" class="btn btn-primary">Posts</router-link>
      </div>
    </div><br/>
    <h2>User List</h2>
    <table class="table table-hover">
    <thead>
    <tr>
      <th>E-mail</th>
      <th>Name</th>
      <th>Number</th>
      <th>Phone Number</th>
      <th>Is Admin</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for="user in users" :key="user._id">
      <td>{{ user.email }}</td>
      <td>{{ user.name }}</td>
      <td>{{ user.number }}</td>
      <td>{{ user.phoneNum }}</td>
      <td>{{ user.isAdmin }}</td>
      <td><router-link :to="{name: 'editUser', params: { resid: user._id, reqid: id }}" class="btn btn-primary">Edit</router-link></td>
      <td><button class="btn btn-danger" @click.prevent="deleteUser(user._id)">Delete</button></td>
    </tr>
    </tbody>
  </table><br/>
    <h2>승인 List</h2>
  <table class="table table-hover">
    <thead>
    <tr>
      <th>E-mail</th>
      <th>Name</th>
      <th>Number</th>
      <th>Phone Number</th>
      <th>Is Admin</th>
      <th>승인</th>
      <th>Delete</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for="waitUser in waitUsers" :key="waitUser._id">
      <td>{{ waitUser.email }}</td>
      <td>{{ waitUser.name }}</td>
      <td>{{ waitUser.number }}</td>
      <td>{{ waitUser.phoneNum }}</td>
      <td>{{ waitUser.isAdmin }}</td>
      <td><button class="btn btn-primary" @click.prevent="approve(waitUser)">승인</button></td>
      <td><button class="btn btn-danger" @click.prevent="deleteWaitUser(waitUser._id)">Delete</button></td>
    </tr>
    </tbody>
  </table>
  </div>
</template>

<script>
export default {
  data () {
    return {
      users: [],
      waitUsers: [],
      id: String
    }
  },
  created () {
    let uri = 'http://localhost:4000/login'
    let uri2 = 'http://localhost:4000/waituser'
    this.id = `${this.$route.params.reqid}`
    this.axios.get(uri).then(response => {
      this.users = response.data
    })
    this.axios.get(uri2).then(response => {
      this.waitUsers = response.data
    })
  },
  methods: {
    deleteUser (id) {
      let uri = `http://localhost:4000/login/delete/${id}`
      this.axios.delete(uri).then(response => {
        // this.posts.splice(this.posts.indexOf(id), 1)
        this.users.pop(this.users.indexOf(id))
      })
    },
    deleteWaitUser (id) {
      let uri = `http://localhost:4000/waituser/delete/${id}`
      this.axios.delete(uri).then(response => {
        // this.posts.splice(this.posts.indexOf(id), 1)
        this.waitUsers.pop(this.waitUsers.indexOf(id))
      })
    },
    approve (waitUser) {
      let uri = 'http://localhost:4000/login/add'
      this.axios.post(uri, waitUser).then(() => {
        this.deleteWaitUser(waitUser._id)
        this.$router.push({ name: 'admin', params: { reqid: this.id } })
      })
    }
  }
}
</script>
