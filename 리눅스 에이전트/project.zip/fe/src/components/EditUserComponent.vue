<template>
  <div>
    <h1>Edit User</h1>
    <form @submit.prevent="updateUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your email:</label>
            <input type="text" class="form-control" v-model="user.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your password:</label>
            <input type="password" class="form-control" v-model="user.password">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your name:</label>
            <input type="text" class="form-control" v-model="user.name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your number:</label>
            <input type="text" class="form-control" v-model="user.number">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your phone number:</label>
            <input type="text" class="form-control" v-model="user.phoneNum">
          </div>
        </div>
      </div>
      <div v-if="isAdmin" class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Are you admin?:</label>
            <input type="checkbox" class="form-control" v-model="user.isAdmin">
          </div>
        </div>
      </div><br/>
      <div class="form-group">
        <button class="btn btn-primary">Edit</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data () {
    return {
      user: {},
      isAdmin: Boolean
    }
  },
  created () {
    this.user.isAdmin = false
    let uri = `http://localhost:4000/login/edit/${this.$route.params.resid}`
    let uri2 = `http://localhost:4000/login/${this.$route.params.reqid}`
    this.axios.get(uri).then((response) => {
      this.user = response.data
    })
    this.axios.get(uri2).then((response) => {
      this.isAdmin = response.data.result
    })
  },
  methods: {
    updateUser () {
      let uri = `http://localhost:4000/login/update/${this.$route.params.resid}`
      this.axios.post(uri, this.user).then(() => {
        /*if (this.user.isAdmin) {
          this.$router.push({ name: 'admin' })
        } else {
          this.$router.push({ name: 'posts', params: { id: this.$route.params.id } })
        }*/
        this.$router.back()
      })
    }
  }
}
</script>
