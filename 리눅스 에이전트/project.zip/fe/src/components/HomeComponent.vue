<template>
  <div>
    <h1>Login</h1>
    <form @submit.prevent="login">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your email:</label>
            <input type="text" class="form-control" v-model="user.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your password:</label>
            <input type="password" class="form-control" v-model="user.password">
          </div>
        </div>
      </div><br/>
      <div class="form-group">
        <button class="btn btn-primary">Login</button>
      </div>
    </form>
    <router-link to="/signup" class="btn btn-primary">Sign Up</router-link>
  </div>
</template>
<script>
export default {
  data () {
    return {
      user: {}
    }
  },
  methods: {
    login () {
      console.log(this.user)
      let uri = 'http://localhost:4000/login'
      this.axios.post(uri, this.user).then(response => {
        let result = response.data.result
        console.log(result)
        if (result === 1) {
          let resUser = response.data.resUser
          console.log('login')
          if (resUser.isAdmin) {
            this.$router.push({ name: 'admin', params: { reqid: resUser._id } })
          } else {
            this.$router.push({ name: 'posts', params: { reqid: resUser._id } })
          }
        } else if (result === -1) {
          console.log('password dismatch')
        } else {
          console.log('not exist user')
        }
      })
    }
  }
}
</script>
