<template>
  <div>
    <h1>Posts</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'editUser', params: { resid: id, reqid: id }}" class="btn btn-primary">Edit</router-link>
        <br/><br/><button class="btn btn-primary" @click.prevent="attend(id)">출석</button>
      </div>
    </div><br/>
    <table class="table table-hover">
      <thead>
      <tr>
        <th>Title</th>
        <th>Body</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="post in posts" :key="post._id">
        <td>{{ post.title }}</td>
        <td>{{ post.body }}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data () {
    return {
      posts: [],
      id: String
    }
  },
  created () {
    this.id = this.$route.params.reqid
    let uri = 'http://localhost:4000/posts'
    this.axios.get(uri).then(response => {
      this.posts = response.data
    })
  },
  methods: {
    attend (id) {
      console.log('출석체크')
    }
  }
}
</script>
