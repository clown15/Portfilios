<template>
  <div>
    <h1>Sign Up</h1>
    <form @submit.prevent="addWaitUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your email:</label>
            <input type="text" class="form-control" v-model="waitUser.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your password:</label>
            <input type="password" class="form-control" v-model="waitUser.password">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your name:</label>
            <input type="text" class="form-control" v-model="waitUser.name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your number:</label>
            <input type="text" class="form-control" v-model="waitUser.number">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Your phone number:</label>
            <input type="text" class="form-control" v-model="waitUser.phoneNum">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Are you admin?:</label>
            <input type="checkbox" class="form-control" v-model="waitUser.isAdmin">
          </div>
        </div>
      </div><br/>
      <div class="form-group">
        <button class="btn btn-primary">Sign Up</button>
      </div>
    </form>
  </div>
</template>
<script>
export default {
  data () {
    return {
      waitUser: {}
    }
  },
  created () {
    this.waitUser.isAdmin = false
  },
  methods: {
    addWaitUser () {
      console.log(this.waitUser)
      let uri = 'http://localhost:4000/waitUser/add'
      this.axios.post(uri, this.waitUser).then(() => {
        this.$router.push({ name: 'home' })
      })
    }
  }
}
</script>
