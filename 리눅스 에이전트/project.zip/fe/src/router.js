import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import CreateComponent from './components/CreateComponent'
import EditComponent from './components/EditComponent'
import Post from './views/Post'
import SignUpComponent from './components/SignUpComponent'
import AdminComponent from './components/AdminComponent'
import EditUserComponent from './components/EditUserComponent'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    },
    {
      path: '/posts/:reqid',
      name: 'posts',
      component: Post
    },
    {
      path: '/create/:reqid',
      name: 'create',
      component: CreateComponent
    },
    {
      path: '/edit/:reqid/:postid',
      name: 'edit',
      component: EditComponent
    },
    {
      path: '/signup',
      name: 'signup',
      component: SignUpComponent
    },
    {
      path: '/admin/:reqid',
      name: 'admin',
      component: AdminComponent
    },
    {
      path: '/edituser/:resid/:reqid',
      name: 'editUser',
      component: EditUserComponent
    }
  ]
})
