<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <homeComponent/>
  </div>
</template>

<script>
// @ is an alias to /src
import homeComponent from '@/components/HomeComponent.vue'

export default {
  name: 'home',
  components: {
    homeComponent
  }
}
</script>
