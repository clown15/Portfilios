<template>
  <div class="posts">
    <adminPostComponent v-if="isAdmin"/>
    <postComponent v-else/>
  </div>
</template>

<script>
// @ is an alias to /src

import postComponent from '@/components/PostComponent.vue'
import adminPostComponent from '@/components/AdminPostComponent.vue'

export default {
  name: 'posts',
  data () {
    return {
      isAdmin: Boolean
    }
  },
  created () {
    let uri = `http://localhost:4000/login/${this.$route.params.reqid}`
    this.axios.get(uri).then(response => {
      this.isAdmin = response.data.result
    })
  },
  components: {
    postComponent, adminPostComponent
  }
}
</script>
